package me.twitterminer.main;

import me.twitterminer.manager.TweetManager;
import me.twitterminer.manager.TwitterCriteria;
import me.twitterminer.model.Tweet;

public class Main {
	private static final String USERNAME = "Username: ";
	private static final String RETWEETS = "Retweets: ";
	private static final String TEXT = "Text: ";
	private static final String MENTIONS = "Mentions: ";
	private static final String HASHTAGS = "Hashtags: ";

	public static void main(String[] args) {
		/**
		 * Reusable objects
		 */
		TwitterCriteria criteria = null;
		Tweet t = null;
		
		/**
		 *  Example 1 - Get tweets by username
		 **/
		
		criteria = TwitterCriteria.create()
				.setUsername("barackobama")
				.setMaxTweets(2000);
		t = TweetManager.getTweets(criteria).get(0);
		
		System.out.println("### Example 1 - Get tweets by username [barackobama]");
		printTweet(t);
		
		/**
		 *  Example 2 - Get tweets by query search
		 **/
		criteria = TwitterCriteria.create()
				.setQuerySearch("oracle benefits")
				.setSince("2015-05-01")
				.setUntil("2017-09-30")
				.setMaxTweets(2100);
		//t = TweetManager.getTweets(criteria).get(0);
		
		for(int i=0; i < TweetManager.getTweets(criteria).size(); i++) {
			t = TweetManager.getTweets(criteria).get(i);
			System.out.print(i + ".) ");
			printTweet(t);

		}
		
		System.out.println("### Example 2 - Get tweets by query search [europe refugees]");
		printTweet(t);
		
		/**
		 *  Example 3 - Get tweets by username and bound dates
		 **/
		criteria = TwitterCriteria.create()
				.setUsername("barackobama")
				.setSince("2015-09-10")
				.setUntil("2015-09-12")
				.setMaxTweets(2000);
		t = TweetManager.getTweets(criteria).get(0);
		
		System.out.println("### Example 3 - Get tweets by username and bound dates [barackobama, '2015-09-10', '2015-09-12']");
		printTweet(t);
	}
	
	private static void printTweet(Tweet t) {
		System.out.println(USERNAME + t.getUsername());
		System.out.println(RETWEETS + t.getRetweets());
		System.out.println(TEXT + t.getText());
		System.out.println(MENTIONS + t.getMentions());
		System.out.println(HASHTAGS + t.getHashtags());
		System.out.println();
	}
}